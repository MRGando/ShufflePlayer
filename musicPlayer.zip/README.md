![Screenshot 2021-12-16 200449](https://user-images.githubusercontent.com/86018280/146411677-41a574a4-0ce4-4401-b975-6731d5b1666d.png)

# MusicPlayer
ShufflePlayer - you can play songs randomly or choose one .
